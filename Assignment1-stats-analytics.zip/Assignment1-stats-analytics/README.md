Embedded system Assingment
Author:Zubair Iqbal
Date :july 1,2025
this projects is about to analysis basic data in c programming language where the functions are used to calculate following :
minimum
maximum
mean 
median
the code also inclides a sorting algorithm and prints all stats

